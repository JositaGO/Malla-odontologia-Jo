# Malla Odontología Jo 🦷

Proyecto interactivo de la malla curricular de la carrera de Odontología, Universidad San Sebastián (USS).

### ✨ Características
- Visualiza los ramos por semestre.
- Solo puedes marcar un ramo si cumpliste sus prerrequisitos.
- Guarda tu progreso automáticamente en el navegador.
- Totalmente personalizable y ampliable.

Hecho con 💖 por Jo y ChatGPT.
